#pragma once
#include"PuzzleTools.h"

class CreateArray : public PuzzleTools
{
public:
	int* random_array(int level);
	int* input_array(int puzzlenum);
private:

};

